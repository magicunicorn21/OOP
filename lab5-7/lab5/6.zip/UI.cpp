#include "UI.h"
#include <sstream>
#include <vector>

using namespace std;

void RunicAltar::printMenuA()
{
	std::cout << "Possible runes:" << std::endl;
	std::cout << "\tmode X (A - full fledged mages / B - apprentices)" << std::endl;
	std::cout << "\tadd powerWordName, material, age, corporealForm" << std::endl;
	std::cout << "\tupdate powerWordName, newMaterial, newAge, newCorporealForm" << std::endl;
	std::cout << "\tdelete powerWordName" << std::endl;
	std::cout << "\tlist" << std::endl;
	std::cout << "\texit" << std::endl;
}

void RunicAltar::printMenuB()
{
    std::cout << "Possible runes:" << std::endl;
    std::cout << "\tmode X (A - full fledged mages / B - apprentices)" << std::endl;
    std::cout << "\tnext" << std::endl;
    std::cout << "\tsave powerWordName" << std::endl;
    std::cout << "\tlist material, age" << std::endl;
    std::cout << "\tmylist" << std::endl;
}

std::vector<std::string> splitCommand(std::string command)
{

    std::stringstream original(command);
    std::string partOfCommand;
    std::vector<std::string> splitted;
    std::getline(original, partOfCommand, ' ');
    splitted.push_back(partOfCommand);
    while (std::getline(original, partOfCommand, ','))
        splitted.push_back(partOfCommand);
    return splitted;
}

void RunicAltar::printAllStatues()
{
    DynamicVector<GuardianStatue> statues = enchantment_.getAllStatues();
    for (int index = 0; index < statues.getSize(); index++)
    {
        GuardianStatue statue = statues[index];
        std::cout << statue.toString() << std::endl;
    }
}

void RunicAltar::printActiveStatues()
{
    DynamicVector<GuardianStatue> statues = enchantment_.getAllActiveStatues();
    for (int index = 0; index < statues.getSize(); index++)
    {
        GuardianStatue statue = statues[index];
        std::cout << statue.toString() << std::endl;
    }
}

void RunicAltar::printFilteredStatues(std::string material, int age)
{
    DynamicVector<GuardianStatue> statues = enchantment_.filterStatues(material, age);
    for (int index = 0; index < statues.getSize(); index++)
    {
        GuardianStatue statue = statues[index];
        std::cout << statue.toString() << std::endl;
    }
}

void RunicAltar::runAMode()
{
    std::string command;
    while (true)
    {
        printMenuA();
        getline(cin, command);
        std::vector<std::string> splittedCommand = splitCommand(command);
        if (splittedCommand[0] == "exit")
            return;
        else if (splittedCommand[0] == "mode" && splittedCommand[1] == "B")
        {
            runBMode();
            return;
        }
        else if (splittedCommand[0] == "add")
            enchantment_.addStatueEnchantment(splittedCommand[1], splittedCommand[2], stoi(splittedCommand[3]), splittedCommand[4]);
        else if (splittedCommand[0] == "delete")
            enchantment_.removeStatueEnchantment(splittedCommand[1]);
        else if (splittedCommand[0] == "update")
            enchantment_.updateStatueEnchantment(splittedCommand[1], splittedCommand[2], stoi(splittedCommand[3]), splittedCommand[4]);
        else if (splittedCommand[0] == "list")
            printAllStatues();
        else
            cout << "Invalid command!" << endl;
    }
}

void RunicAltar::runBMode()
{
    std::string command;
    while (true)
    {
        printMenuB();
        getline(cin, command);
        std::vector<std::string> splittedCommand = splitCommand(command);
        if (splittedCommand[0] == "exit")
            return;
        else if (splittedCommand[0] == "mode" && splittedCommand[1] == "A")
        {
            runAMode();
            return;
        }
        else if (splittedCommand[0] == "next")
        {
            GuardianStatue nextStatue = enchantment_.next();
            cout << nextStatue.toString() << endl;
        }
        else if (splittedCommand[0] == "save")
            enchantment_.addActiveStatue(splittedCommand[1]);
        else if (splittedCommand[0] == "list")
            printFilteredStatues(splittedCommand[1], stoi(splittedCommand[2]));
        else if (splittedCommand[0] == "mylist")
            printActiveStatues();
        else
            cout << "Invalid command!" << endl;
    }
}

void RunicAltar::run()
{
    std::string mode;
    bool modeChosen = false;
    while (!modeChosen)
    {
        std::cout << "Choose mode (A - full fledged mages / B - apprentices): " << endl;
        std::getline(std::cin, mode);
        if (mode == "mode A")
        {
            runAMode();
            modeChosen = true;
        }
        else if (mode == "mode B")
        {
            runBMode();
            modeChosen = true;
        }
        else if (mode == "exit")
            modeChosen = true;
        else
            cout << "Invalid mode!" << endl;
    }
}
